var app = angular.module('myApp', []);
var appRoute = angular.module('myAppRoute', ['ngRoute', 'ngAnimate']);


appRoute.controller('myCtrl', function($scope) {
    $scope.firstName = "Anil Kumar";
    $scope.lastName = "Jain";
});
app.controller('navCtrl', function($scope) {
    //$scope.contentPage='introduction';
    $scope.reset = function(rightContentPage) {
	     /*$scope.introPage = angular.copy($scope.master);*/
		 if(rightContentPage == 'undefined' || rightContentPage == null){
		   rightContentPage='introduction';
		 }
		$scope.contentPage=rightContentPage;
		alert("rightContentPage " + rightContentPage);
		$scope.introductionPageVisible=false;
		$scope.page1Visible=false;
		if(rightContentPage=='introduction'){
		$scope.introductionPageVisible=true;
		alert("inside  if 1:" + $scope.introductionPageVisible);
		}
		if(rightContentPage=='page2'){
		$scope.introductionPageVisible=false;
		$scope.page1Visible=true;
		alert("inside  if 2" + $scope.page1Visible + " "+ $scope.introductionPageVisible);
		}
		
    };
    $scope.reset();
});
/*
appRoute.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/introduction', {
        templateUrl: 'introduction.html',
        controller: 'IntroductionController'
      }).
      when('/page2', {
        templateUrl: 'page2.html',
        controller: 'Page2Controller'
      }).
      otherwise({
        redirectTo: '/introduction'
      });
  }]);
  
  appRoute.controller('Page2Controller', function($scope) {
     
    $scope.message = 'This is Page 2 screen';
     
});
*/
appRoute.config(function($routeProvider) {
    $routeProvider
    	.when('/', {
    		templateUrl: 'introduction.html',
            controller: 'mainController'
    	})
    	.when('/introduction', {
    		templateUrl: 'introduction.html',
            controller: 'introductionController'
    	})
    	.when('/page2', {
    		templateUrl: 'page2.html',
            controller: 'page2Controller'
    	});

});

appRoute.controller('mainController', function($scope) {
    //$scope.pageClass = 'page-home';
});

appRoute.controller('introductionController', function($scope) {
    //$scope.pageClass = 'page-about';
});

appRoute.controller('page2Controller', function($scope) {
    //$scope.pageClass = 'page-contact';
});
  